$(document).ready(function() {
 
  var chartColours = ['#96CA59', '#3F97EB', '#72c380', '#6f7a8a', '#f7cb38', '#5a8022', '#2c7282'];

  //generate random number for charts
  randNum = function() {
    return (Math.floor(Math.random() * (1 + 40 - 20))) + 20;
  };

  var d1 = [];
  //var d2 = [];

  //here we generate data for chart
  for (var i = 0; i < 30; i++) {
    d1.push([new Date(Date.today().add(i).days()).getTime(), randNum() + i + i + 10]);
    //    d2.push([new Date(Date.today().add(i).days()).getTime(), randNum()]);
  }

  var chartMinDate = d1[0][0]; //first day
  var chartMaxDate = d1[20][0]; //last day

  var tickSize = [1, "day"];
  var tformat = "%d/%m/%y";

  //graph options
  var options = {
    grid: {
      show: true,
      aboveData: true,
      color: "#3f3f3f",
      labelMargin: 10,
      axisMargin: 0,
      borderWidth: 0,
      borderColor: null,
      minBorderMargin: 5,
      clickable: true,
      hoverable: true,
      autoHighlight: true,
      mouseActiveRadius: 100
    },
    series: {
      lines: {
        show: true,
        fill: true,
        lineWidth: 2,
        steps: false
      },
      points: {
        show: true,
        radius: 4.5,
        symbol: "circle",
        lineWidth: 3.0
      }
    },
    legend: {
      position: "ne",
      margin: [0, -25],
      noColumns: 0,
      labelBoxBorderColor: null,
      labelFormatter: function(label, series) {
        // just add some space to labes
        return label + '&nbsp;&nbsp;';
      },
      width: 40,
      height: 1
    },
    colors: chartColours,
    shadowSize: 0,
    tooltip: true, //activate tooltip
    tooltipOpts: {
      content: "%s: %y.0",
      xDateFormat: "%d/%m",
      shifts: {
        x: -30,
        y: -50
      },
      defaultTheme: false
    },
    yaxis: {
      min: 0
    },
    xaxis: {
      mode: "time",
      minTickSize: tickSize,
      timeformat: tformat,
      min: chartMinDate,
      max: chartMaxDate
    }
  };
  var plot = $.plot($("#placeholder33x"), [{
    label: "Email Sent",
    data: d1,
    lines: {
      fillColor: "rgba(150, 202, 89, 0.12)"
    }, //#96CA59 rgba(150, 202, 89, 0.42)
    points: {
      fillColor: "#fff"
    }
  }], options);
});
//Flot 

//jQuery Sparklines

$(document).ready(function() {
  $(".sparkline_one").sparkline([2, 4, 3, 4, 5, 4, 5, 4, 3, 4, 5, 6, 4, 5, 6, 3, 5, 4, 5, 4, 5, 4, 3, 4, 5, 6, 7, 5, 4, 3, 5, 6], {
    type: 'bar',
    height: '125',
    barWidth: 13,
    colorMap: {
      '7': '#a1a1a1'
    },
    barSpacing: 2,
    barColor: '#26B99A'
  });

  $(".sparkline11").sparkline([2, 4, 3, 4, 5, 4, 5, 4, 3, 4, 6, 2, 4, 3, 4, 5, 4, 5, 4, 3], {
    type: 'bar',
    height: '40',
    barWidth: 8,
    colorMap: {
      '7': '#a1a1a1'
    },
    barSpacing: 2,
    barColor: '#26B99A'
  });

  $(".sparkline22").sparkline([2, 4, 3, 4, 7, 5, 4, 3, 5, 6, 2, 4, 3, 4, 5, 4, 5, 4, 3, 4, 6], {
    type: 'line',
    height: '40',
    width: '200',
    lineColor: '#26B99A',
    fillColor: '#ffffff',
    lineWidth: 3,
    spotColor: '#34495E',
    minSpotColor: '#34495E'
  });
});
//jQuery Sparklines

//Doughnut Chart
$(document).ready(function() {
  var canvasDoughnut,
      options = {
        legend: false,
        responsive: false
      };

  new Chart(document.getElementById("canvas1i"), {
    type: 'doughnut',
    tooltipFillColor: "rgba(51, 51, 51, 0.55)",
    data: {
      labels: [
        "Symbian",
        "Blackberry",
        "Other",
        "Android",
        "IOS"
      ],
      datasets: [{
        data: [15, 20, 30, 10, 30],
        backgroundColor: [
          "#BDC3C7",
          "#9B59B6",
          "#E74C3C",
          "#26B99A",
          "#3498DB"
        ],
        hoverBackgroundColor: [
          "#CFD4D8",
          "#B370CF",
          "#E95E4F",
          "#36CAAB",
          "#49A9EA"
        ]

      }]
    },
    options: options
  });

  new Chart(document.getElementById("canvas1i2"), {
    type: 'doughnut',
    tooltipFillColor: "rgba(51, 51, 51, 0.55)",
    data: {
      labels: [
        "Symbian",
        "Blackberry",
        "Other",
        "Android",
        "IOS"
      ],
      datasets: [{
        data: [15, 20, 30, 10, 30],
        backgroundColor: [
          "#BDC3C7",
          "#9B59B6",
          "#E74C3C",
          "#26B99A",
          "#3498DB"
        ],
        hoverBackgroundColor: [
          "#CFD4D8",
          "#B370CF",
          "#E95E4F",
          "#36CAAB",
          "#49A9EA"
        ]

      }]
    },
    options: options
  });

  new Chart(document.getElementById("canvas1i3"), {
    type: 'doughnut',
    tooltipFillColor: "rgba(51, 51, 51, 0.55)",
    data: {
      labels: [
        "Symbian",
        "Blackberry",
        "Other",
        "Android",
        "IOS"
      ],
      datasets: [{
        data: [15, 20, 30, 10, 30],
        backgroundColor: [
          "#BDC3C7",
          "#9B59B6",
          "#E74C3C",
          "#26B99A",
          "#3498DB"
        ],
        hoverBackgroundColor: [
          "#CFD4D8",
          "#B370CF",
          "#E95E4F",
          "#36CAAB",
          "#49A9EA"
        ]

      }]
    },
    options: options
  });
});
//Doughnut Chart
